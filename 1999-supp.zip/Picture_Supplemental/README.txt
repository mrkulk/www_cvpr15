CVPR Paper Title - "Picture: A probabilistic programming language for scene perception"
Paper ID: 1999

Inference trajectory from prior to posterior on a representative images for various probabilistic programs

Note: 

(a) observed_testimage.jpg is the observed test image
(b) Movie in each experiment folder shows the trajectory of how Picture iteratively samples the posterior scene latents starting from the prior.


Examples:
(1) 3D Pose Estimation Program: The observed image and representative inference trajectory can be found in the '3D_Pose_MOVIE' folder

(2) 3D Shape Reconstruction Program: The observed image and representative inference trajectory can be found in the '3D_Shape_MOVIE' folder

(2) 3D Face Program: The observed image and representative inference trajectory can be found in the '3D_Face_MOVIE' folder
